﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Explorer
{
    public class Map
    {
        public Square[,] Squares { get; }
        public const int Width = 20;  // Custom width
        public const int Height = 20;  // Custom height

        public Map()
        {
            // Create new 2D array of Squares (width by height)
            // Loop through every Square, instantiate as new Square()
            
        }

        public void Draw()
        {
            // Clear Screen
            // Loop through Square 2D array, 
            //      Get display of every individual Square
            //      Use Screen.WriteAt to display the character at the current row/col
            

            // have the next output print under the map.
            Screen.SetCursorPosition(0, Height + 2);
        }

        // Same function!? (Overloading). Difference?
        public void Draw(int x, int y)
        {
            char display = Squares[x, y].Display;
            Screen.WriteAt(display, x, y);
        }
    }

    public class Square
    {
        public char Display { get; } = '.';  // Custom Character here!
    }
}